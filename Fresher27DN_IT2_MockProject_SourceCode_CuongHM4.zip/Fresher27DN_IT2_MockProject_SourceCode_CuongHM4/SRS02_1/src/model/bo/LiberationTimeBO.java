package model.bo;

import java.util.ArrayList;

import model.bean.LiberationTime;
import model.dao.LiberationTimeDAO;

public class LiberationTimeBO {
	LiberationTimeDAO liberationTime = new LiberationTimeDAO();
	public ArrayList<LiberationTime> getListLiberationTime() {
		return liberationTime.getListLiberationTime();
	}
}
