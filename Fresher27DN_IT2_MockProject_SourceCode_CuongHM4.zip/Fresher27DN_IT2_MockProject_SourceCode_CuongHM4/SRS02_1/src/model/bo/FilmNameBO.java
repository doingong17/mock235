package model.bo;

import java.util.ArrayList;

import model.bean.FilmName;
import model.dao.FilmNameDAO;



public class FilmNameBO {
	FilmNameDAO FilmNameDAO = new FilmNameDAO();
	public ArrayList<FilmName> getListFilmName() {
		return FilmNameDAO.getListFilmName();
	}
}
