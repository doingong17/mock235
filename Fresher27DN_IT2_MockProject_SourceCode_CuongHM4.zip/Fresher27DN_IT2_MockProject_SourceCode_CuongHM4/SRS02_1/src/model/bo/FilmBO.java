package model.bo;

import java.util.ArrayList;

import form.ListFilmForm;
import model.bean.Film;
import model.dao.FilmDAO;

public class FilmBO {
	FilmDAO filmDAO = new FilmDAO();
	public ArrayList<Film> getListFilm(int offset, int noOfRecords) {
		return filmDAO.getListFilm(offset, noOfRecords);
	}
	public ArrayList<Film> getSearchFilm(Film film, int offset, int noOfRecords){
		return filmDAO.getSearchFilm(film, offset, noOfRecords);
	}
	
	public void addFilm(String filmId, String filmDayOfYear, String filmTime){
		filmDAO.addFilm(filmId, filmDayOfYear, filmTime);
	}
}
