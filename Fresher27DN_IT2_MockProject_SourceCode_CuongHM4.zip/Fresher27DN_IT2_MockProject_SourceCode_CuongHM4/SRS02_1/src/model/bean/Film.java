package model.bean;

import java.util.ArrayList;

public class Film {
	private String filmDayOfWeek;
	private String filmDayOfYear;
	private String filmTime;
	private String filmId;
	private String filmName;
	private String characterId;
	private String characterName;
	private String liberationTimeId;
	private String liberationTimeName;
	private String constructor;
	private String director;
	private String filmImage;
	
	
	/**
	 * @return the filmDayOfWeek
	 */
	public String getFilmDayOfWeek() {
		return filmDayOfWeek;
	}
	/**
	 * @param filmDayOfWeek the filmDayOfWeek to set
	 */
	public void setFilmDayOfWeek(String filmDayOfWeek) {
		this.filmDayOfWeek = filmDayOfWeek;
	}
	/**
	 * @return the filmDayOfYear
	 */
	public String getFilmDayOfYear() {
		return filmDayOfYear;
	}
	/**
	 * @param filmDayOfYear the filmDayOfYear to set
	 */
	public void setFilmDayOfYear(String filmDayOfYear) {
		this.filmDayOfYear = filmDayOfYear;
	}
	/**
	 * @return the filmTime
	 */
	public String getFilmTime() {
		return filmTime;
	}
	/**
	 * @param filmTime the filmTime to set
	 */
	public void setFilmTime(String filmTime) {
		this.filmTime = filmTime;
	}
	/**
	 * @return the filmId
	 */
	public String getFilmId() {
		return filmId;
	}
	/**
	 * @param filmId the filmId to set
	 */
	public void setFilmId(String filmId) {
		this.filmId = filmId;
	}
	/**
	 * @return the filmName
	 */
	public String getFilmName() {
		return filmName;
	}
	/**
	 * @param filmName the filmName to set
	 */
	public void setFilmName(String filmName) {
		this.filmName = filmName;
	}
	/**
	 * @return the characterId
	 */
	public String getCharacterId() {
		return characterId;
	}
	/**
	 * @param characterId the characterId to set
	 */
	public void setCharacterId(String characterId) {
		this.characterId = characterId;
	}
	/**
	 * @return the characterName
	 */
	public String getCharacterName() {
		return characterName;
	}
	/**
	 * @param characterName the characterName to set
	 */
	public void setCharacterName(String characterName) {
		this.characterName = characterName;
	}
	/**
	 * @return the liberationTimeId
	 */
	public String getLiberationTimeId() {
		return liberationTimeId;
	}
	/**
	 * @param liberationTimeId the liberationTimeId to set
	 */
	public void setLiberationTimeId(String liberationTimeId) {
		this.liberationTimeId = liberationTimeId;
	}
	/**
	 * @return the liberationTimeName
	 */
	public String getLiberationTimeName() {
		return liberationTimeName;
	}
	/**
	 * @param liberationTimeName the liberationTimeName to set
	 */
	public void setLiberationTimeName(String liberationTimeName) {
		this.liberationTimeName = liberationTimeName;
	}
	/**
	 * @return the constructor
	 */
	public String getConstructor() {
		return constructor;
	}
	/**
	 * @param constructor the constructor to set
	 */
	public void setConstructor(String constructor) {
		this.constructor = constructor;
	}
	/**
	 * @return the director
	 */
	public String getDirector() {
		return director;
	}
	/**
	 * @param director the director to set
	 */
	public void setDirector(String director) {
		this.director = director;
	}
	/**
	 * @return the filmImage
	 */
	public String getFilmImage() {
		return filmImage;
	}
	/**
	 * @param filmImage the filmImage to set
	 */
	public void setFilmImage(String filmImage) {
		this.filmImage = filmImage;
	}	
}
