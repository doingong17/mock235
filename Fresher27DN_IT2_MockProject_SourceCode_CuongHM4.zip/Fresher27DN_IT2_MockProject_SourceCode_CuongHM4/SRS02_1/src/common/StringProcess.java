package common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class StringProcess {
	public static boolean notVaild(String s){
		if(s==null || s.length()==0) return true;
		return false;
	}
	public static boolean notVaildLiberationTime(String s){
		if("来ている".equals(s)) return true;
		return false;
	}
	public static boolean notVaildFilmName(String s){
		if("Doctor-Strange".equals(s)) return true;
		return false;
	}
	public static boolean notVaildDayOfWeek(String s){
		if(s==null || s.length()==0) return true;
		return false;
	}
	public static boolean checkDayofWeek(String s){
		if (s.trim().equals("")) {
			return false;
		}
		if("Monday".equals(s.trim())|| "Tuesday".equals(s.trim()) || "Wednesday".equals(s.trim()) || "Thursday".equals(s.trim()) || "Friday".equals(s.trim()) || "Saturday".equals(s.trim()) || "Sunday".equals(s.trim())) return false;
		return true;
	}

	public static boolean checkDayOfYear(String strDate) {
		if (strDate.trim().equals("")) {
			return false;
		} else {
			SimpleDateFormat sdfrmt = new SimpleDateFormat("yyyy/MM/dd");
			sdfrmt.setLenient(false);
			Date javaDate = null;
			try {
				javaDate = sdfrmt.parse(strDate);
			} catch (ParseException e) {
				return true;
			}
			return false;
		}
	}
	
	public static boolean checkTime(String strTime) {
		if (strTime.trim().equals("")) {
			return false;
		} else {
			SimpleDateFormat sdfrmt = new SimpleDateFormat("HH:mm");
			sdfrmt.setLenient(false);
			Date javaTime = null;
			try {
				javaTime = sdfrmt.parse(strTime);
			} catch (ParseException e) {
				return true;
			}
			return false;
		}
	}
}
